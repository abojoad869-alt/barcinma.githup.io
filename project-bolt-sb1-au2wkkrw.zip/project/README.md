# BARcinema - Original Movies & Series Platform

🎬 **BARcinema** is a modern, responsive platform for showcasing original movies and series content. Built with React, TypeScript, and Tailwind CSS.

## 🌟 Features

- **Bilingual Support** (English/Arabic) with RTL layout
- **Responsive Design** optimized for all devices
- **SEO Optimized** with meta tags and structured data
- **Performance Optimized** with lazy loading and code splitting
- **Admin Panel** for content management
- **Analytics Integration** (Google Analytics & Facebook Pixel)
- **PWA Ready** with service worker support

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation
```bash
# Clone the repository
git clone https://github.com/yourusername/barcinema.git
cd barcinema

# Install dependencies
npm install

# Start development server
npm run dev
```

### Build for Production
```bash
# Build the project
npm run build

# Preview the build
npm run preview
```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
├── contexts/           # React contexts (Language, etc.)
├── data/              # Static data (movies, series)
├── pages/             # Page components
├── types/             # TypeScript type definitions
├── utils/             # Utility functions
└── App.tsx            # Main application component
```

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the root directory:

```env
VITE_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
VITE_FACEBOOK_PIXEL_ID=XXXXXXXXXX
VITE_SITE_URL=https://barcinema.com
```

### Analytics Setup
1. Replace `G-XXXXXXXXXX` with your Google Analytics 4 tracking ID
2. Replace `YOUR_PIXEL_ID` with your Facebook Pixel ID
3. Update the tracking IDs in `src/components/Analytics.tsx`

## 🌐 Deployment

### Netlify
1. Connect your GitHub repository to Netlify
2. Build settings are configured in `netlify.toml`
3. Deploy automatically on push to main branch

### Vercel
1. Import your project to Vercel
2. Configuration is in `vercel.json`
3. Deploy with zero configuration

### Manual Deployment
```bash
# Build the project
npm run build

# Upload the 'dist' folder to your hosting provider
```

## 📈 SEO & Marketing

### SEO Features
- ✅ Meta tags and Open Graph
- ✅ Structured data (JSON-LD)
- ✅ XML Sitemap
- ✅ Robots.txt
- ✅ Canonical URLs
- ✅ Performance optimization

### Marketing Checklist
- [ ] Set up Google Analytics
- [ ] Configure Facebook Pixel
- [ ] Submit sitemap to Google Search Console
- [ ] Create social media accounts
- [ ] Set up email marketing
- [ ] Plan content marketing strategy

## 🛡️ Security

- HTTPS enforced
- Security headers configured
- XSS protection enabled
- Content Security Policy
- Admin panel password protected

## 🎨 Customization

### Branding
- Update logo in `src/components/Header.tsx`
- Modify colors in `tailwind.config.js`
- Update site name throughout the application

### Content
- Add movies/series in `src/data/`
- Modify translations in `src/utils/translations.ts`
- Update contact information

## 📱 PWA Features

- Offline support
- App-like experience
- Install prompt
- Push notifications ready

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 📞 Support

For support, email contact@barcinema.com or create an issue on GitHub.

---

**BARcinema** - Your destination for original entertainment content! 🎭✨