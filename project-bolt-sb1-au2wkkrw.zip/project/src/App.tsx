import React, { useState } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import { useLanguage } from './contexts/LanguageContext';
import SEOHead from './components/SEOHead';
import Analytics from './components/Analytics';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import MovieDetailPage from './pages/MovieDetailPage';
import SeriesDetailPage from './pages/SeriesDetailPage';
import CategoriesPage from './pages/CategoriesPage';
import MostViewedPage from './pages/MostViewedPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import AdminPage from './pages/AdminPage';
import { Movie, Series } from './types';

type PageType = 'home' | 'movies' | 'series' | 'anime' | 'categories' | 'contact' | 'about' | 'most-viewed' | 'movie-detail' | 'series-detail' | 'admin';

function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [selectedSeries, setSelectedSeries] = useState<Series | null>(null);

  const handlePageChange = (page: string) => {
    setCurrentPage(page as PageType);
    setSelectedMovie(null);
    setSelectedSeries(null);
  };

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setCurrentPage('movie-detail');
  };

  const handleSeriesClick = (series: Series) => {
    setSelectedSeries(series);
    setCurrentPage('series-detail');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onMovieClick={handleMovieClick} onSeriesClick={handleSeriesClick} />;
      case 'movie-detail':
        return selectedMovie ? (
          <MovieDetailPage movie={selectedMovie} onBack={() => setCurrentPage('home')} />
        ) : (
          <HomePage onMovieClick={handleMovieClick} onSeriesClick={handleSeriesClick} />
        );
      case 'series-detail':
        return selectedSeries ? (
          <SeriesDetailPage series={selectedSeries} onBack={() => setCurrentPage('home')} />
        ) : (
          <HomePage onMovieClick={handleMovieClick} onSeriesClick={handleSeriesClick} />
        );
      case 'categories':
        return <CategoriesPage />;
      case 'most-viewed':
        return <MostViewedPage onMovieClick={handleMovieClick} onSeriesClick={handleSeriesClick} />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      case 'admin':
        return <AdminPage />;
      case 'movies':
      case 'series':
      case 'anime':
        // For now, redirect to home - you can implement dedicated pages later
        return <HomePage onMovieClick={handleMovieClick} onSeriesClick={handleSeriesClick} />;
      default:
        return <HomePage onMovieClick={handleMovieClick} onSeriesClick={handleSeriesClick} />;
    }
  };

  return (
    <LanguageProvider>
      <Analytics trackingId="G-XXXXXXXXXX" />
      <AppContent 
        currentPage={currentPage}
        handlePageChange={handlePageChange}
        renderPage={renderPage}
      />
    </LanguageProvider>
  );
}

interface AppContentProps {
  currentPage: PageType;
  handlePageChange: (page: string) => void;
  renderPage: () => React.ReactNode;
}

function AppContent({ currentPage, handlePageChange, renderPage }: AppContentProps) {
  const { t, language } = useLanguage();

  // SEO data based on current page
  const getSEOData = () => {
    switch (currentPage) {
      case 'home':
        return {
          title: 'BARcinema - Original Movies & Series Platform',
          description: 'Discover exclusive original movies and series. High-quality entertainment created with passion and creativity.',
          url: 'https://barcinema.com'
        };
      case 'movies':
        return {
          title: 'Movies - BARcinema',
          description: 'Browse our collection of original movies. High-quality entertainment created by our production team.',
          url: 'https://barcinema.com/movies'
        };
      case 'series':
        return {
          title: 'Series - BARcinema',
          description: 'Watch exclusive original series. Compelling stories and characters created with passion.',
          url: 'https://barcinema.com/series'
        };
      case 'categories':
        return {
          title: 'Categories - BARcinema',
          description: 'Browse movies and series by genre. Find your favorite type of entertainment.',
          url: 'https://barcinema.com/categories'
        };
      case 'about':
        return {
          title: 'About Us - BARcinema',
          description: 'Learn about BARcinema and our mission to create original entertainment content.',
          url: 'https://barcinema.com/about'
        };
      case 'contact':
        return {
          title: 'Contact Us - BARcinema',
          description: 'Get in touch with the BARcinema team. We love hearing from our audience.',
          url: 'https://barcinema.com/contact'
        };
      default:
        return {
          title: 'BARcinema - Original Movies & Series Platform',
          description: 'Your destination for original entertainment content.',
          url: 'https://barcinema.com'
        };
    }
  };

  const seoData = getSEOData();

  return (
    <div className={`min-h-screen bg-gray-50 ${language.dir === 'rtl' ? 'rtl' : 'ltr'}`}>
      <SEOHead {...seoData} />
      <Header currentPage={currentPage} onPageChange={handlePageChange} />
      {renderPage()}
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold mb-4">BARcinema</h3>
              <p className="text-gray-400 text-sm">
                {t('footerDescription')}
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">{t('quickLinks')}</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => handlePageChange('home')} className="text-gray-400 hover:text-white transition-colors">{t('home')}</button></li>
                <li><button onClick={() => handlePageChange('movies')} className="text-gray-400 hover:text-white transition-colors">{t('movies')}</button></li>
                <li><button onClick={() => handlePageChange('series')} className="text-gray-400 hover:text-white transition-colors">{t('series')}</button></li>
                <li><button onClick={() => handlePageChange('categories')} className="text-gray-400 hover:text-white transition-colors">{t('categories')}</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">{t('support')}</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => handlePageChange('about')} className="text-gray-400 hover:text-white transition-colors">{t('aboutUs')}</button></li>
                <li><button onClick={() => handlePageChange('contact')} className="text-gray-400 hover:text-white transition-colors">{t('contact')}</button></li>
                <li><button onClick={() => handlePageChange('admin')} className="text-gray-400 hover:text-white transition-colors">{t('rateUs')}</button></li>
                <li><button onClick={() => handlePageChange('most-viewed')} className="text-gray-400 hover:text-white transition-colors">{t('mostViewed')}</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">{t('connect')}</h4>
              <div className={`flex ${language.dir === 'rtl' ? 'space-x-reverse space-x-4' : 'space-x-4'}`}>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Facebook</a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Twitter</a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">Instagram</a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>© 2025 BARcinema. All rights reserved. Original content created by our production team.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;